# 理財目標規劃器

用現值（PV）、終值（FV）與每月存款（PMT）分析理財目標的純靜態網頁，無需建置、無後端。

## 資料夾結構

```
finance-goal-planner/
├── public/
│   ├── index.html   # 網站本體（單一檔案）
│   └── _headers     # Cloudflare 安全標頭
├── package.json     # 本機預覽與部署指令
├── .gitignore
└── README.md
```

## 本機預覽

直接用瀏覽器開啟 `public/index.html`，或執行：

```bash
npm run dev
```

## 上傳到 GitHub

```bash
cd finance-goal-planner
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/<你的帳號>/finance-goal-planner.git
git push -u origin main
```

（先在 GitHub 建立一個空的 repository，名稱 `finance-goal-planner`，不要勾選加入 README。）

## 部署到 Cloudflare Pages（連結 GitHub）

1. Cloudflare 後台 → Workers & Pages → Create → Pages → Connect to Git。
2. 選擇 `finance-goal-planner` repository。
3. 建置設定：
   - Framework preset：None
   - Build command：留空
   - Build output directory：`public`
4. 點 Save and Deploy。之後每次 push 到 `main` 都會自動重新部署。

## 用指令部署（選用）

```bash
npm run deploy
```

第一次執行會要求登入 Cloudflare。

## 免責聲明

本工具僅依輸入的假設做試算，不構成投資建議。
